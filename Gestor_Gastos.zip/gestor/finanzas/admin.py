from django.contrib import admin
from .models import Gasto, Ingreso

admin.site.register(Gasto)
admin.site.register(Ingreso)
